var searchData=
[
  ['dump_5finfo',['dump_info',['../alloc_8h.html#a694aaf4db4218ea977f8bcb854018e91',1,'alloc.h']]],
  ['dyn_5falloc',['dyn_alloc',['../alloc_8h.html#ae67e85cdac67d48573b331408e96869a',1,'alloc.h']]],
  ['dyn_5ffree',['dyn_free',['../alloc_8h.html#af44251aace580649f07d46312ee3338f',1,'alloc.h']]]
];
