#include "alloc.h"

int main(void)
{
    char *ptr = NULL;
    int var = 5;

    while (--var) {
        ptr = my_alloc(sizeof(char) * 10);
        if (NULL == ptr) {
            printf("my_alloc failed\n");
            return 0;
        }
        printf("ptr - addr --> %p\n", ptr);
        binary();
    }
    return 0;
}
