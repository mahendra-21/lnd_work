
#ifndef HEADER_1_H
#define HEADER_1_H

#include <stdio.h>

float ADD(float n1, float n2);
float SUB(float n1, float n2);
float MUL(float n1, float n2);
float DIVI(float n1, float n2);

#endif
