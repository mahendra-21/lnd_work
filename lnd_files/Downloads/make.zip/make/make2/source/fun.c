#include "header_1.h"

float ADD(float n1, float n2)
{
	return (n1 + n2);
}

float SUB(float n1, float n2)
{
	return (n1 - n2);
}

float MUL(float n1, float n2)
{
	return (n1 * n2);
}

float DIVI(float n1, float n2)
{
	return (n1 / n2);
}
