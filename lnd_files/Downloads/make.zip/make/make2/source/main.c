#include "header_1.h"

int main()
{
	int choice = 0;
	float n1, n2;
	system("clear");
	
	do{
		printf ("\n\t1. ADD\n\t2. SUB \n\t3. MUL\n\t4. DIV\n\t0. EXIT");
		printf ("\n\tEnter your choice \t:\t");
		scanf ("%d", &choice);

		switch(choice)
		{
			case 1:
				printf ("\n\tEnter two numbers \t:\n\t");
				scanf ("%f", &n1);
				printf ("\t");
				scanf ("%f", &n2);
				printf ("\n\tAddition is = %.2f\n", ADD(n1,n2));
				break;

			case 2:
				printf ("\n\tEnter two numbers \t:\n\t");
				scanf ("%f", &n1);
				printf ("\t");
				scanf ("%f", &n2);
				printf ("\n\tSubtraction is = %f\n", SUB(n1,n2));
				break;

			case 3:
				printf ("\n\tEnter two numbers \t:\n\t");
				scanf ("%f", &n1);
				printf ("\t");
				scanf ("%f", &n2);
				printf ("\n\tMultiplication is = %f\n", MUL(n1,n2));
				break;

			case 4:
				printf ("\n\tEnter two numbers \t:\n\t");
				scanf ("%f", &n1);
				printf ("\t");
				scanf ("%f", &n2);
				printf ("\n\tDivision is = %f\n", DIVI(n1,n2));
				break;

			case 0:
				break;
	
			default:
				printf ("\n\tInvalid input\n");
		}
	}while(choice != 0);
	return 0;
}
