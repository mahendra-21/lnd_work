#include "header.h"

int main(void)
{
    char arr[127]; 
    int sock_fd; // session descriptor for socket
    int sock_accept; // session descriptor for client 
    unsigned int len;

    struct sockaddr_in  ipOfserver; // For server IP
    
    /* Creating a socket/session */
    sock_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (-1 == sock_fd) {
        handle_error("socket");
    }

    /* Assigning a name to a socket */
    ipOfserver.sin_family = AF_INET;
    ipOfserver.sin_port = htons(2500);
    ipOfserver.sin_addr.s_addr = htonl(INADDR_ANY);

    memset(arr, 0, sizeof(arr));
    memset(&ipOfserver, 0, sizeof(struct sockaddr_in));
    len = sizeof(struct sockaddr_in);

    if (-1 == bind(sock_fd, (struct sockaddr *) &ipOfserver, len)) {
        handle_error("bind");
    }

    /* Listen for connections on a socket */
    if (-1 == listen(sock_fd, 5)) {
        handle_error("listen");
    }

    /* Accept a connection on a socket */
    sock_accept = accept(sock_fd, (struct sockaddr *) &ipOfserver, &len);
    if (-1 == sock_accept) {
        handle_error("accept");
    }
    
    /* Reading data from the client */
    if (-1 == read(sock_accept, arr, sizeof(arr))) {
        handle_error("read");
    }

    printf("In server -> %s\n", arr);

    return 0;
}
