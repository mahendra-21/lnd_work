#include<stdio.h>
int main(void)
{
	int a =	10;
	int b = 20;
	int c = add(a,b);
	int d = sub(a,b);
	printf("%d %d\n",c,d);
	return 0;
}

