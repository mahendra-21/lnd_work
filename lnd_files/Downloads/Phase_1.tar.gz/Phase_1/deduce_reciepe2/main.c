#include "header.h"

int main(void)
{
	printf("Executing within main..\n");
	display();
	hello();
	world();
return 0;
}
