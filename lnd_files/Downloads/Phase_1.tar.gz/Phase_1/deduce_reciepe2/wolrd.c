#include "header.h"

void world()
{
	printf("Within world function..\n");
}
