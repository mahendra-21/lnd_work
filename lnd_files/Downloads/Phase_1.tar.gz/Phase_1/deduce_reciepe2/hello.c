#include "header.h"

void hello()
{
	printf("In hello..\n");
}
