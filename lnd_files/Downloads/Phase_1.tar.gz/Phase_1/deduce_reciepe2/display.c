#include "header.h"

void display()
{
	printf("Within display..\n");
	hello();
	world();
	printf("Exiting display..\n");
}
