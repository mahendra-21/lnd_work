int sub(int a,int b)
{
	int d=a-b;
	return d;
}

