int sub(int a,int b)
{
	int d = b - a;
	return d;
}

