#include<stdio.h>
#include"header.h"

void message()
{
        printf("\nMessage function\n");
}

