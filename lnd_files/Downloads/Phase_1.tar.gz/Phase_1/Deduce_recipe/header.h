#include <stdio.h>

void display();
void message();
