#include<stdio.h>

int main()
{
	display();
	message();
}
