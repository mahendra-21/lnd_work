
#include"header.h"

void display()
{
	printf("\nDisplay function\n");
}
