#include "header.h"

void message()
{
	printf("This is message function\n");
	printf("Exiting message.........");

}
