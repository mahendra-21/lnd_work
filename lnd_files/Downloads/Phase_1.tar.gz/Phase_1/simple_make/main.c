#include "header.h"

int main(void)
{
	display();
	message();
return 0;
}
