#include<stdio.h>

void dispaly();
void message();
