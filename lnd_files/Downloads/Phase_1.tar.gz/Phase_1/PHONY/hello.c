#include "header.h"

void hello (void)
{
	printf("Printing in hello...\n");

}
