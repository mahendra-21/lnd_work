#include "header.h"

int main(void)
{
	printf("In MAIN..\n");
	display();
	hello();
	//clean();
return 0;
}
