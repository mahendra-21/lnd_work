#include "header.h"

void display (void)
{
	printf("Printing in display...\n");

}
